const app =new Vue({
	el:'#app',
	data:{
		list:[
		{
			id:1,
			booksName:'《算法导论》',
			booksDate:'2006-9',
			price:85.00,
			num:1
		},
		{
			id:2,
			booksName:'《UNIX编程艺术》',
			booksDate:'2006-2',
			price:59.00,
			num:1
		},
		{
			id:3,
			booksName:'《编程机制》',
			booksDate:'2008-10',
			price:39.00,
			num:1
		},
		{
			id:4,
			booksName:'《代码大全》',
			booksDate:'2006-3',
			price:128.00,
			num:1
		}
		]
	},
	methods:{
		/*getPrice(price){
		return "￥"+price.toFixed(2)
		}*/
		increment(index){
		 //console.log("increment",index);
		 return this.list[index].num++
		},
		decrement(index){
		 return this.list[index].num--
		},
		removeClick(index){
			return this.list.splice(index,1);	
		}
	},
	computed:{
		totalPrice(){
		let totalPrice = 0
			for(let i=0;i<this.list.length;i++){
			 totalPrice += this.list[i].price * this.list[i].num
			}
			return totalPrice
		}
	},
	filters:{
	getPrice(price){
	return "￥"+price.toFixed(2)
	}
	}
	
})